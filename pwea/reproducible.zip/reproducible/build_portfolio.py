import pandas as pd
import numpy as np

from scipy import stats as sps

def my_shift(pd_obj, periods=1, extend=False, freq=None):
    if extend:
        pd_obj = pd_obj.copy()
        for new_dt in pd.date_range(start=pd_obj.index[-1], freq=freq, periods=periods + 1)[1:]:
            pd_obj.loc[new_dt] = np.nan
    return pd_obj.shift(periods)

def my_ffill(pd_obj, stop=True, limit=None):
    if stop:
        pd_obj = pd_obj.copy()
        from_idx = pd_obj.first_valid_index()
        to_idx = pd_obj.last_valid_index()
        # Use .ffill() instead of fillna(method='ffill')
        pd_obj.loc[from_idx: to_idx] = pd_obj.loc[from_idx: to_idx].ffill(limit=limit)
        #pd_obj.loc[from_idx: to_idx] = pd_obj.loc[from_idx: to_idx].fillna(method='ffill', limit=limit)
        return pd_obj
    else:
        return pd_obj.fillna(method='ffill', limit=limit)

def _rp_weights(conviction_df, natural_ret_df, window, min_window, return_lag=1):
    natural_ret_df = my_shift(natural_ret_df, periods=return_lag, extend=True, freq='B')
    vol_norm_scaling_df = 1 / natural_ret_df.ewm(span=window, min_periods=min_window).std()
    port_weight_df = vol_norm_scaling_df.mul(conviction_df, axis=1)
    port_weight_df = port_weight_df.dropna(how='all', axis=0)
    return port_weight_df


def _agg_correlation(df, freq, window, min_window):
    groupped_df = df.groupby(pd.Grouper(freq=freq)).apply(lambda g: g.sum(skipna=False))
    return groupped_df.ewm(span=window, min_periods=min_window).corr()


def _vol_scale_weights(weights_df, natural_ret_df, port_sigma_tgt_s, window, min_window,
                       return_lag=1, long_corr=False):
    """
    calculate target weights for each asset to achieve the expected target level of vol
    """

    num_dates = weights_df.shape[0]
    num_assets = weights_df.shape[1]

    weights_df = weights_df.sort_index(axis=1)
    natural_ret_df = natural_ret_df[weights_df.columns].sort_index(axis=1)

    natural_ret_df = my_shift(natural_ret_df, periods=return_lag, extend=True, freq='B')

    if long_corr:
        day_ls = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
        # Window is now in weeks, so 250 = 5 years
        partial_corr_ls = [_agg_correlation(natural_ret_df, 'W-' + day, window, min_window) for day in day_ls]
        corr_mdf = pd.concat(partial_corr_ls, axis=0, sort=True)

        std_df = natural_ret_df.ewm(span=window, min_periods=min_window).std()

        corr_mdf = corr_mdf.sort_index(axis=0, level=[0, 1]).sort_index(axis=1)
        std_df = std_df.sort_index(axis=1)

        corr = corr_mdf.loc[weights_df.index].values.reshape(num_dates, num_assets, num_assets)
        std = std_df.loc[weights_df.index].values.reshape(num_dates, num_assets, 1)

        cov = (corr * np.matmul(std, std.transpose(0, 2, 1)))
    else:
        cov_mdf = natural_ret_df.ewm(span=window, min_periods=min_window).cov()
        cov = cov_mdf.loc[weights_df.index].values.reshape(num_dates, num_assets, num_assets)

    weights = weights_df.values

    a_arr = np.matmul(weights.reshape(num_dates, 1, num_assets), cov)  # w * Sigma, in 3d
    port_var = np.matmul(a_arr, weights.reshape(num_dates, num_assets, 1)).reshape(num_dates)  # (w*S) * wT
    port_std = np.sqrt(port_var)
    port_std_s = pd.Series(port_std, index=weights_df.index)
    port_std_s = port_std_s.replace({np.inf: np.nan, -np.inf: np.nan}).ffill()
    vol_scalar_s = port_sigma_tgt_s / port_std_s

    return vol_scalar_s, port_std_s


def _sticky_scalar(vol_scalar_s, port_std_s, port_sigma_tgt_s):
    new_sigma_tgt_scalar_s = pd.Series()
    first_idx = vol_scalar_s.first_valid_index()
    last_value = vol_scalar_s.loc[first_idx]
    new_sigma_tgt_scalar_s.loc[first_idx] = last_value
    port_std_s = port_std_s.fillna(method='ffill')

    vol_lb_s = 0.6 * port_sigma_tgt_s
    vol_ub_s = 1.2 * port_sigma_tgt_s
    for idx, val in vol_scalar_s.items():
        estimated_vol = port_std_s.loc[idx] * last_value
        if (estimated_vol < vol_lb_s.loc[idx]) or (estimated_vol > vol_ub_s.loc[idx]):
            last_value = vol_scalar_s.fillna(method='ffill').loc[idx]
        new_sigma_tgt_scalar_s.loc[idx] = last_value
    return new_sigma_tgt_scalar_s


def _remove_holidays(weight_df, holiday_dd):
    out_df = pd.DataFrame()
    for column in weight_df.columns:
        weight_s = weight_df[column]
        weight_s = weight_s.loc[weight_s.first_valid_index():weight_s.last_valid_index()].copy()
        holiday_ls = holiday_dd[column]
        holiday_ls = sorted(list(set(holiday_ls).intersection(set(weight_s.index))))
        weight_s.loc[holiday_ls] = np.nan
        weight_s = weight_s.ffill()
        out_df = pd.concat([out_df, weight_s], axis=1, sort=True)
    return out_df


def _add_t_costs(tgt_weight_df, t_cost_s):
    """
    trading and funding costs
    """
    t_cost_s = t_cost_s[tgt_weight_df.columns]
    t_cost_df = tgt_weight_df.diff().abs().mul(t_cost_s)
    return t_cost_df


def calculate(weights_df, natural_ret_df, var_tgt_daily_pct=None, risk_parity=True, sticky_scalar=False,
              max_leverage=None, max_gross_exp=None, holiday_dd=None, t_cost_s=None, window=250, min_window=125,
              return_lag=1, long_corr=False):
    """
    construct portfolio with a target vol, conviction weighted, and resulting NAV

    t_costs: all duration / bps adjustments must been done before this.
    """

    # calculate weights
    natural_ret_df = natural_ret_df[weights_df.columns].copy()

    out_dd = dict()
    out_dd['original_weight'] = weights_df
    if risk_parity:
        weights_df = _rp_weights(weights_df, natural_ret_df, window=window, min_window=min_window,
                                 return_lag=return_lag)
        out_dd['rp_weight'] = weights_df

    port_sigma_tgt_s = None
    if var_tgt_daily_pct is not None:
        if isinstance(var_tgt_daily_pct, float):
            port_sigma_tgt_s = pd.Series(var_tgt_daily_pct / sps.norm.ppf(0.975), index=weights_df.index)
        else:
            port_sigma_tgt_s = pd.Series(var_tgt_daily_pct / sps.norm.ppf(0.975))

        vol_scalar_s, port_std_s = _vol_scale_weights(weights_df, natural_ret_df, port_sigma_tgt_s,
                                                      window=window, min_window=min_window, return_lag=return_lag,
                                                      long_corr=long_corr)
        out_dd['vol_scalar'] = vol_scalar_s
        out_dd['port_std_s'] = port_std_s

        if sticky_scalar:
            vol_scalar_s = _sticky_scalar(vol_scalar_s, port_std_s, port_sigma_tgt_s)
            out_dd['sticky_vol_scalar'] = vol_scalar_s

        vol_scalar_s = vol_scalar_s.replace([np.inf, -np.inf], 0)
        weights_df = weights_df.mul(vol_scalar_s, axis=0).replace([np.inf, -np.inf], np.nan)
        out_dd['vs_weight'] = weights_df

    weights_df = my_ffill(weights_df, stop=True)
    weights_df = weights_df.dropna(how='all', axis=0)  # drop initial

    out_dd['uncapped_tgt_weight'] = weights_df.copy()
    if max_leverage is not None:
        weights_df = weights_df.clip(lower=-max_leverage, upper=max_leverage)

    if max_gross_exp is not None:
        exp_s = weights_df.abs().sum(axis=1)
        scale_s = exp_s.clip(upper=max_gross_exp) / exp_s
        weights_df = weights_df.mul(scale_s, axis='index')

    if holiday_dd is not None:
        weights_df = _remove_holidays(weights_df, holiday_dd)

    out_dd['tgt_weight'] = weights_df

    if port_sigma_tgt_s is not None:
        _, tgt_std_s = _vol_scale_weights(weights_df, natural_ret_df, port_sigma_tgt_s,
                                          window=window, min_window=min_window, return_lag=return_lag)
        out_dd['targeted_port_std_s'] = tgt_std_s

    # calculate portfolio NAV
    start_dt = max(weights_df.shift(return_lag).index[0], natural_ret_df.index[0])
    port_ret_df = weights_df.shift(return_lag).loc[start_dt:].mul(natural_ret_df.loc[start_dt:], axis=0)
    out_dd['port_ret'] = port_ret_df

    if t_cost_s is not None:
        t_cost_s = t_cost_s[weights_df.columns].copy()
        t_costs_df = _add_t_costs(weights_df, t_cost_s=t_cost_s)
        t_port_ret_df = port_ret_df.loc[start_dt:] - t_costs_df.loc[start_dt:]
        out_dd['t_port_ret'] = t_port_ret_df
        out_dd['t_cost'] = t_costs_df.copy()

    return out_dd


def calculate_basket(weights_df, natural_ret_df, basket_assts_dd, var_tgt_daily_pct, basket_weights_s=None,
                     risk_parity=True, sticky_scalar=False, max_leverage=None, max_gross_exp=None, holiday_dd=None,
                     t_cost_s=None, window=250, min_window=125,
                     return_lag=1, long_corr=False):
    basket_portfolios_dd = dict()
    original_weight_df = weights_df.copy()

    for basket_name, asset_ls in basket_assts_dd.items():
        port_dd = calculate(weights_df[asset_ls], natural_ret_df[asset_ls], var_tgt_daily_pct=var_tgt_daily_pct,
                            risk_parity=risk_parity, sticky_scalar=False,
                            max_leverage=None, max_gross_exp=None, holiday_dd=None, t_cost_s=None,
                            window=window, min_window=min_window, return_lag=return_lag, long_corr=long_corr)

        basket_portfolios_dd[basket_name] = port_dd

    basket_cret_df = pd.concat({basket_name: port_dd['port_ret'].sum(axis=1)
                                for basket_name, port_dd in basket_portfolios_dd.items()}, axis=1, sort=True)

    if basket_weights_s is None:
        basket_weights_s = pd.Series(1, index=basket_cret_df.columns)

    signal_df = basket_cret_df.copy()
    signal_df[:] = 1.
    signal_df = signal_df.mul(basket_weights_s, axis=1)

    agg_port_dd = calculate(signal_df, basket_cret_df, var_tgt_daily_pct=var_tgt_daily_pct,
                            risk_parity=False, sticky_scalar=False,
                            max_leverage=None, max_gross_exp=None, holiday_dd=None, t_cost_s=None,
                            window=window, min_window=min_window, return_lag=return_lag, long_corr=long_corr)

    new_weight_df = pd.DataFrame()
    for basket_name, asset_ls in basket_assts_dd.items():
        basket_weight_df = basket_portfolios_dd[basket_name]['tgt_weight'].mul(
            agg_port_dd['tgt_weight'][basket_name], axis=0)
        new_weight_df = pd.concat([new_weight_df, basket_weight_df], axis=1, sort=True)

    initial_weights_df = weights_df.dropna(axis=0, how='all')
    initial_dd = calculate(initial_weights_df, natural_ret_df, var_tgt_daily_pct=var_tgt_daily_pct,
                           risk_parity=risk_parity, sticky_scalar=sticky_scalar,
                           max_leverage=None, max_gross_exp=None, holiday_dd=None, t_cost_s=None,
                           window=window, min_window=min_window, return_lag=return_lag, long_corr=long_corr)

    early_weight_df = initial_dd['tgt_weight']
    early_weight_df = early_weight_df.dropna(axis=0, how='all')
    new_weight_df = new_weight_df.dropna(axis=0, how='all')
    early_weight_df = early_weight_df.loc[:new_weight_df.index[0]]

    missing_dt_ls = list(set(early_weight_df.index).difference(new_weight_df.index))

    new_weight_df = pd.concat([early_weight_df.loc[missing_dt_ls],
                               new_weight_df], axis=0, sort=True).sort_index()

    out_dd = calculate(new_weight_df, natural_ret_df[new_weight_df.columns], var_tgt_daily_pct=var_tgt_daily_pct,
                       risk_parity=False, sticky_scalar=False,
                       max_leverage=max_leverage, max_gross_exp=max_gross_exp, holiday_dd=holiday_dd, t_cost_s=t_cost_s,
                       window=window, min_window=min_window, return_lag=return_lag, long_corr=long_corr)

    out_dd['no_basket_tgt_weight'] = early_weight_df
    out_dd['original_weight'] = original_weight_df

    return out_dd
